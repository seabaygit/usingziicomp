<ul class="menu menu-dropdown">
	<li class="level1 parent">
		<span class="level1 parent">
			<span><?php echo $title; ?></span>
		</span>
		<div class="dropdown columns1" <?php echo $dropdownwidth; ?>>
			<div class="dropdown-bg">
				<div>
					<div class="module"><?php echo $content; ?></div>
				</div>
			</div>
		</div>
	</li>
</ul>
