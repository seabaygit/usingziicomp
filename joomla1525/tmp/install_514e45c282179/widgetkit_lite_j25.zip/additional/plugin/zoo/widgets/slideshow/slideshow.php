<?php
/**
* @package   Widgetkit
* @author    YOOtheme http://www.yootheme.com
* @copyright Copyright (C) YOOtheme GmbH
* @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
*/

/*
	Class: ZooSlideshow
		Zoo Slideshow class
*/
class ZooSlideshow extends ZooWidget {}

// instantiate ZooSlideshow
new ZooSlideshow();