<div class="module <?php echo $style; ?>">

	<?php echo $badge; ?>
	
	<div class="box-t">
		<div>
			<div></div>
		</div>
	</div>
	
	<div class="box-m">
		<div class="deepest">
		
			<?php if ($showtitle) echo $title; ?>
			<?php echo $content; ?>
				
		</div>
	</div>

	<div class="box-b">
		<div>
			<div></div>
		</div>
	</div>
		
</div>